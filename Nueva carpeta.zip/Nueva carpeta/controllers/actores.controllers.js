
exports.crearActor = (req, res) => {
    res.render('actor/crearActor'); 
};
exports.editarActor = (req, res) => {
    res.render('actor/editarActor'); 
};
exports.eliminarActor = (req, res) => {
    res.render('actor/eliminarActor'); 
};